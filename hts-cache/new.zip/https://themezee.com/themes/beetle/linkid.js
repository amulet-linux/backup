<!DOCTYPE html>
<html lang="en-US">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://themezee.com/xmlrpc.php">
<link rel="shortcut icon" href="/wp-content/uploads/favicon.ico" />

<title>Nothing found for  Themes Beetle Linkid Js</title>
<meta name="generator" content="This site uses EU VAT for EDD by Lyquidity (1.5.12) using 2015 rules" />
<!-- All in One SEO Pack 2.3.9.2 by Michael Torbert of Semper Fi Web Design[317,355] -->
<!-- /all in one seo pack -->
<link rel='dns-prefetch' href='//www.google.com' />
<link rel='dns-prefetch' href='//cdn.themezee.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="ThemeZee &raquo; Feed" href="https://themezee.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="ThemeZee &raquo; Comments Feed" href="https://themezee.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/cdn.themezee.com\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='theme-my-login-css'  href='https://cdn.themezee.com/wp-content/plugins/theme-my-login/theme-my-login.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://cdn.themezee.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='edd-styles-css'  href='https://cdn.themezee.com/wp-content/themes/themezee-magazine/edd_templates/edd.css?ver=2.6.8' type='text/css' media='all' />
<link rel='stylesheet' id='themezee-stylesheet-css'  href='https://cdn.themezee.com/wp-content/themes/themezee-magazine/style.css?ver=20160906' type='text/css' media='all' />
<link rel='stylesheet' id='themezee-genericons-css'  href='https://cdn.themezee.com/wp-content/themes/themezee-magazine/css/genericons/genericons.css' type='text/css' media='all' />
<link rel='stylesheet' id='themezee-templates-css'  href='https://cdn.themezee.com/wp-content/themes/themezee-magazine/css/templates.css?ver=20160906' type='text/css' media='all' />
<link rel='stylesheet' id='themezee-default-fonts-css'  href='https://fonts.googleapis.com/css?family=Arimo%3A400%2C400italic%2C700%2C700italic%7CHammersmith+One&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='jquery.lightbox.min.css-css'  href='https://cdn.themezee.com/wp-content/plugins/wp-jquery-lightbox/styles/lightbox.min.css?ver=1.4.6' type='text/css' media='all' />
<!-- This site uses the Google Analytics by MonsterInsights plugin v5.5.2 - Universal enabled - https://www.monsterinsights.com/ -->
<script type="text/javascript">
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

	__gaTracker('create', 'UA-4734666-2', 'auto');
	__gaTracker('set', 'forceSSL', true);
	__gaTracker('set', 'anonymizeIp', true);
	__gaTracker('require', 'displayfeatures');
	__gaTracker('require', 'linkid', 'linkid.js');
	__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);

</script>
<!-- / Google Analytics by MonsterInsights -->
<script type='text/javascript' src='https://cdn.themezee.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/themezee.com\/wp-admin\/admin-ajax.php","position_in_cart":"-1","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","ajax_loader":"\/wp-content\/plugins\/easy-digital-downloads\/assets\/images\/loading.gif","is_checkout":"0","default_gateway":"paypal","redirect_to_checkout":"0","checkout_page":"https:\/\/themezee.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.6.8'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var themezee_edd_products = {"76761":"Extended Bundle","76760":"Standard Bundle","73300":"Gambit Pro","71884":"ThemeZee Mega Menu","69758":"Admiral Pro","65584":"Maxwell Pro","62420":"Gridbox Pro","58567":"zeeDynamic Pro","58393":"Beetle Pro","56518":"Tortuga Pro","56016":"ThemeZee Social Sharing","53694":"Poseidon Pro","51298":"ThemeZee Related Posts","49729":"ThemeZee Breadcrumbs","41305":"ThemeZee Widget Bundle","40511":"Merlin Pro","34895":"Glades Pro","29405":"Premium Bundle","28632":"Leeway Pro","27578":"Courage Pro","24587":"Momentous Pro","22947":"All 11 Themes Bundle","22945":"Anderson Pro","20048":"Rubine Pro","19642":"Dynamic News Pro","13955":"Smartline Pro","9558":"Test Product","7158":"Lifetime Bundle"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/themezee-framework/assets/js/themezee-events.js?ver=20151205'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js'></script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/theme-my-login/modules/themed-profiles/themed-profiles.js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/themes/themezee-magazine/js/html5shiv.min.js?ver=3.7.2'></script>
<![endif]-->
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/themes/themezee-magazine/js/navigation.js'></script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/themes/themezee-magazine/js/sidebar.js'></script>
<link rel='https://api.w.org/' href='https://themezee.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://themezee.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://themezee.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.6.1" />
<meta name="generator" content="Easy Digital Downloads v2.6.8" />
</head>

<body class="error404">

	<div id="page" class="hfeed site">
		
		<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
		
		<header id="masthead" class="site-header clearfix" role="banner">
			
			<div class="header-main container clearfix">
						
				<div id="logo" class="site-branding clearfix">
				
					<a href="https://themezee.com/" title="ThemeZee" rel="home">
						<h1 class="site-title">ThemeZee</h1>
					</a>
					
					<p class="site-description">Magazine WordPress Themes since 2010</p>
				
				</div><!-- .site-branding -->
				
				<div class="header-content-wrap clearfix">
					
					
	<div id="header-content" class="header-content clearfix">

			<div id="polylang-language-selector" class="language-switcher clearfix">
				
				<div class="current"><span><img src="https://themezee.com/wp-content/plugins/polylang/flags/us.png" />en</span></div><a href="https://themezee.com/de/">
				<span><img src="https://themezee.com/wp-content/plugins/polylang/flags/de.png" />de</span>
			</a>					
			</div>
				
			<div id="header-social-icons" class="social-icons-navigation clearfix">

				<ul id="menu-social-icons" class="social-icons-menu"><li id="menu-item-20283" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20283"><a href="http://themezee.com/feed/"><span class="screen-reader-text">Subscribe RSS Feed</span></a></li>
<li id="menu-item-20284" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20284"><a target="_blank" href="http://twitter.com/ThemeZee"><span class="screen-reader-text">Follow us on Twitter</span></a></li>
<li id="menu-item-20285" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20285"><a target="_blank" href="http://www.facebook.com/pages/ThemeZee/125188360890238"><span class="screen-reader-text">Become a Facebook Fan</span></a></li>
<li id="menu-item-20286" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20286"><a href="https://themezee.com/newsletter/"><span class="screen-reader-text">Subscribe our Newsletter</span></a></li>
</ul>			
			</div>
		
	</div>					
				</div><!-- .header-content-wrap -->
			
			</div><!-- .header-main -->
		
		</header><!-- #masthead -->
		
		<div id="main-navigation-wrap" class="primary-navigation-wrap">
		
			<nav id="main-navigation" class="primary-navigation navigation container clearfix" role="navigation">
				<ul id="menu-main-navigation" class="main-navigation-menu"><li id="menu-item-51123" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51123"><a href="https://themezee.com/">Home</a></li>
<li id="menu-item-3492" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3492"><a href="https://themezee.com/themes/">Themes</a></li>
<li id="menu-item-53294" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-53294"><a href="https://themezee.com/addons/">Add-ons</a></li>
<li id="menu-item-46362" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-46362"><a href="https://themezee.com/plugins/">Plugins</a></li>
<li id="menu-item-7149" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7149"><a href="https://themezee.com/pricing/">Pricing</a></li>
<li id="menu-item-5142" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5142"><a href="https://themezee.com/support/">Support</a>
<ul class="sub-menu">
	<li id="menu-item-2802" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2802"><a href="https://themezee.com/docs/">Documentation</a></li>
	<li id="menu-item-5145" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5145"><a href="https://themezee.com/videos/">Video tutorials</a></li>
	<li id="menu-item-20262" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20262"><a href="https://themezee.com/faq/">Frequently Asked Questions</a></li>
	<li id="menu-item-1471" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1471"><a href="https://themezee.com/contact/">Contact</a></li>
</ul>
</li>
<li id="menu-item-3494" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-3494"><a href="https://themezee.com/blog/">Blog</a></li>
<li id="menu-item-20290" class="menu-item-right menu-item-cart menu-item menu-item-type-post_type menu-item-object-page menu-item-20290"><a href="https://themezee.com/checkout/">Cart</a></li>
<li class="menu-item menu-item-right menu-item-account menu-item-type-custom "><a href="https://themezee.com/login/">Login</a></ul>			</nav><!-- #main-navigation -->
			
		</div>
		
		<div id="content" class="site-content container clearfix">
		
	<section id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<div class="error-404 not-found type-page">
			
				<header class="entry-header">
		
					<h1 class="page-title">404: Page not found</h1>
					
				</header><!-- .entry-header -->
				
				<div class="entry-content clearfix">
					<p>It looks like nothing was found at this location. Maybe try a search or one of the links below?</p>
					
					
	<form role="search" method="get" class="search-form" action="https://themezee.com/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s">
		</label>
		<button type="submit" class="search-submit">
			<span class="genericon-search"></span>
		</button>
	</form>

<br/>
					
					<h4>Navigation</h4>
					<ul id="menu-main-navigation-1" class="404-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51123"><a href="https://themezee.com/">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3492"><a href="https://themezee.com/themes/">Themes</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-53294"><a href="https://themezee.com/addons/">Add-ons</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-46362"><a href="https://themezee.com/plugins/">Plugins</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7149"><a href="https://themezee.com/pricing/">Pricing</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5142"><a href="https://themezee.com/support/">Support</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2802"><a href="https://themezee.com/docs/">Documentation</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5145"><a href="https://themezee.com/videos/">Video tutorials</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20262"><a href="https://themezee.com/faq/">Frequently Asked Questions</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1471"><a href="https://themezee.com/contact/">Contact</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-3494"><a href="https://themezee.com/blog/">Blog</a></li>
<li class="menu-item-right menu-item-cart menu-item menu-item-type-post_type menu-item-object-page menu-item-20290"><a href="https://themezee.com/checkout/">Cart</a></li>
<li class="menu-item menu-item-right menu-item-account menu-item-type-custom "><a href="https://themezee.com/login/">Login</a></ul>
				</div>
				
			</div>

		</main><!-- #main -->
	</section><!-- #primary -->
	
		<section id="secondary" class="sidebar widget-area clearfix" role="complementary">
	
		<aside class="widget widget-subscribe">
			<h3 class="widget-title">Stay in Touch</h3>
			<div id="widget-social-icons" class="social-icons-navigation clearfix">
				<ul id="menu-social-icons-1" class="social-icons-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20283"><a href="http://themezee.com/feed/">Subscribe RSS Feed</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20284"><a target="_blank" href="http://twitter.com/ThemeZee">Follow us on Twitter</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20285"><a target="_blank" href="http://www.facebook.com/pages/ThemeZee/125188360890238">Become a Facebook Fan</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20286"><a href="https://themezee.com/newsletter/">Subscribe our Newsletter</a></li>
</ul>			</div>
		</aside>

		<aside id="polylang-2" class="widget widget_polylang clearfix"><h3 class="widget-title">Switch Language</h3><ul>
	<li class="lang-item lang-item-1163 lang-item-en lang-item-first current-lang no-translation"><a lang="en-US" hreflang="en-US" href="https://themezee.com/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" title="English" alt="English" /><span style="margin-left:0.3em;">English</span></a></li>
	<li class="lang-item lang-item-1166 lang-item-de no-translation"><a lang="de-DE" hreflang="de-DE" href="https://themezee.com/de/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAGzSURBVHjaYvTxcWb4+53h3z8GZpZff/79+v3n/7/fDAz/GHAAgABi+f37e3FxOZD1Dwz+/v3z9y+E/AMFv3//+Qumfv9et241QACxMDExAVWfOHkJJAEW/gUEP0EQDn78+AHE/gFOQJUAAcQiy8Ag8O+fLFj1n1+/QDp+/gQioK7fP378+vkDqOH39x9A/RJ/gE5lAAhAYhzcAACCQBDkgRXRjP034R0IaDTZTFZn0DItot37S94KLOINerEcI7aKHAHE8v/3r/9//zIA1f36/R+o4tevf1ANYNVA9P07RD9IJQMDQACxADHD3z8Ig4GMHz+AqqHagKp//fwLVA0U//v7LwMDQACx/LZiYFD7/5/53/+///79BqK/EMZ/UPACSYa/v/8DyX9A0oTxx2EGgABi+a/H8F/m339BoCoQ+g8kgRaCQvgPJJiBYmAuw39hxn+uDAABxMLwi+E/0PusRkwMvxhBGoDkH4b/v/+D2EDyz///QB1/QLb8+sP0lQEggFh+vGXYM2/SP6A2Zoaf30Ex/J+PgekHwz9gQDAz/P0FYrAyMfz7wcDAzPDtFwNAgAEAd3SIyRitX1gAAAAASUVORK5CYII=" title="Deutsch" alt="Deutsch" /><span style="margin-left:0.3em;">Deutsch</span></a></li>
</ul>
</aside><aside id="text-21" class="widget widget_text clearfix"><h3 class="widget-title">Featured Theme</h3>			<div class="textwidget"><p><a href="http://themezee.com/themes/dynamicnews/"><img  src="https://cdn.themezee.com/wp-content/uploads/2014/07/screenshot2.png" class="wp-post-image" alt="screenshot" height="600" width="800"></a></p>
<p><a href="http://themezee.com/themes/dynamicnews/"><strong>Dynamic News</strong></a> - A responsive, multipurpose blogging and magazine theme with bold colors and fonts. It comes with a featured content slider and a magazine page template.</p>
</div>
		</aside><aside id="text-22" class="widget widget_text clearfix"><h3 class="widget-title">Need help with your theme?</h3>			<div class="textwidget"><p>You will find a lot of tutorials and videos how to setup and configure your theme in our support center.</p>
<p><a href="http://themezee.com/support/" class="button">Visit Support Center</a></p>
</div>
		</aside><aside id="categories-6" class="widget widget_categories clearfix"><h3 class="widget-title">Blog: Categories</h3>		<ul>
	<li class="cat-item cat-item-53"><a href="https://themezee.com/category/news/" >News</a>
</li>
	<li class="cat-item cat-item-1390"><a href="https://themezee.com/category/plugins/" >Plugins</a>
</li>
	<li class="cat-item cat-item-1082"><a href="https://themezee.com/category/themes/" >Themes</a>
</li>
		</ul>
</aside><aside id="archives-4" class="widget widget_archive clearfix"><h3 class="widget-title">Blog: Archives</h3>		<ul>
			<li><a href='https://themezee.com/2016/08/'>August 2016</a></li>
	<li><a href='https://themezee.com/2016/07/'>July 2016</a></li>
	<li><a href='https://themezee.com/2016/05/'>May 2016</a></li>
	<li><a href='https://themezee.com/2016/04/'>April 2016</a></li>
	<li><a href='https://themezee.com/2016/03/'>March 2016</a></li>
	<li><a href='https://themezee.com/2016/02/'>February 2016</a></li>
	<li><a href='https://themezee.com/2015/12/'>December 2015</a></li>
	<li><a href='https://themezee.com/2015/11/'>November 2015</a></li>
	<li><a href='https://themezee.com/2015/10/'>October 2015</a></li>
	<li><a href='https://themezee.com/2015/09/'>September 2015</a></li>
	<li><a href='https://themezee.com/2015/07/'>July 2015</a></li>
	<li><a href='https://themezee.com/2015/06/'>June 2015</a></li>
	<li><a href='https://themezee.com/2015/04/'>April 2015</a></li>
	<li><a href='https://themezee.com/2015/03/'>March 2015</a></li>
	<li><a href='https://themezee.com/2015/02/'>February 2015</a></li>
	<li><a href='https://themezee.com/2014/12/'>December 2014</a></li>
	<li><a href='https://themezee.com/2014/11/'>November 2014</a></li>
	<li><a href='https://themezee.com/2014/09/'>September 2014</a></li>
	<li><a href='https://themezee.com/2014/08/'>August 2014</a></li>
	<li><a href='https://themezee.com/2014/07/'>July 2014</a></li>
	<li><a href='https://themezee.com/2014/06/'>June 2014</a></li>
	<li><a href='https://themezee.com/2014/05/'>May 2014</a></li>
	<li><a href='https://themezee.com/2014/04/'>April 2014</a></li>
	<li><a href='https://themezee.com/2014/02/'>February 2014</a></li>
	<li><a href='https://themezee.com/2013/12/'>December 2013</a></li>
	<li><a href='https://themezee.com/2013/10/'>October 2013</a></li>
	<li><a href='https://themezee.com/2013/09/'>September 2013</a></li>
	<li><a href='https://themezee.com/2013/08/'>August 2013</a></li>
	<li><a href='https://themezee.com/2013/07/'>July 2013</a></li>
	<li><a href='https://themezee.com/2013/02/'>February 2013</a></li>
	<li><a href='https://themezee.com/2012/12/'>December 2012</a></li>
	<li><a href='https://themezee.com/2012/09/'>September 2012</a></li>
	<li><a href='https://themezee.com/2012/05/'>May 2012</a></li>
	<li><a href='https://themezee.com/2012/04/'>April 2012</a></li>
	<li><a href='https://themezee.com/2011/06/'>June 2011</a></li>
	<li><a href='https://themezee.com/2011/05/'>May 2011</a></li>
		</ul>
		</aside>
	</section><!-- #secondary -->

	</div><!-- #content -->

		
	<div id="footer-widgets-wrap" class="footer-widgets-wrap">
	
		<div id="footer-widgets" class="footer-widgets container clearfix" role="complementary">			

			<div class="footer-widgets-columns clearfix">	
			
				<div class="footer-widget-column">
				
					<aside class="widget widget_nav_menu widget-menu-links">
						<h3 class="widget-title">ThemeZee Links</h3>
						<ul>
							<li>
								<a href="https://themezee.com/">Home</a>
							</li>
							<li>
								<a href="https://themezee.com/blog/">Read the Blog</a>
							</li>
							<li>
								<a href="https://themezee.com/about/">About ThemeZee</a>
							</li>
							<li>
								<a href="https://themezee.com/contact/">Contact</a>
							</li>
						</ul>
					</aside>
					
				</div>
				
				<div class="footer-widget-column">
					
					<aside class="widget widget_nav_menu widget-menu-links">
						<h3 class="widget-title">Our Themes</h3>
						<ul>
							<li>
								<a href="https://themezee.com/themes/">Browse our Themes</a>
							</li>
							<li>
								<a href="https://themezee.com/reviews/">What customers say about us</a>
							</li>
							<li>
								<a href="https://themezee.com/pricing/">Pricing & Details</a>
							</li>
							<li>
								<a target="_blank" href="http://theme.wordpress.com/themes/by/themezee/">ThemeZee on WordPress.com</a>
							</li>
						</ul>
					</aside>
				
				</div>
			
				<div class="footer-widget-column">
				
					<aside class="widget widget_nav_menu widget-menu-links">
						<h3 class="widget-title">Get Support</h3>
						<ul>
							<li>
								<a href="https://themezee.com/support/">Support Center</a>
							</li>
							<li>
								<a href="https://themezee.com/docs/">Theme Documentation</a>
							</li>
							<li>
								<a href="https://themezee.com/videos/">Video Tutorials</a>
							</li>
							<li>
								<a href="https://themezee.com/docs/about-theme-customization/">Theme Customization</a>
							</li>
						</ul>
					</aside>
					
				</div>
			
				<div class="footer-widget-column">
					
					<aside class="widget widget-subscribe">
						<h3 class="widget-title">Stay in Touch</h3>
						<div id="footer-social-icons" class="social-icons-navigation clearfix">
							<ul id="menu-social-icons-2" class="social-icons-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20283"><a href="http://themezee.com/feed/">Subscribe RSS Feed</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20284"><a target="_blank" href="http://twitter.com/ThemeZee">Follow us on Twitter</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20285"><a target="_blank" href="http://www.facebook.com/pages/ThemeZee/125188360890238">Become a Facebook Fan</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20286"><a href="https://themezee.com/newsletter/">Subscribe our Newsletter</a></li>
</ul>						</div>
					</aside>
					
				</div>
		
			</div>
		
		</div>
	
	</div>
	<footer id="colophon" class="site-footer" role="contentinfo">

		<div class="footer-line container clearfix">

			<div id="footer-text" class="site-info">

				© 2016 Themezee.com <a href="https://themezee.com/terms/" title="Terms and Conditions">Terms and Conditions</a> <a href="https://themezee.com/privacy-policy/" title="Privacy Policy">Privacy Policy</a> <a href="https://themezee.com/legal-notice/" title="Legal Notice">Legal Notice</a>
			</div><!-- .site-info -->

			<div class="credit-link">

				made with love in Germany <a href="#">Go to top</a>
			</div>

		</div>

	</footer><!-- #colophon -->

</div><!-- #page -->

<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"https:\/\/themezee.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.5.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var boxzilla_options = {"testMode":"","boxes":[{"id":57913,"icon":"&times;","content":"<h3>Sign-up to our Newsletter and get our <a href=\"https:\/\/themezee.com\/plugins\/widget-bundle\/\">Widget Bundle<\/a> for free!<\/h3>\n<p>\n\t\t<div id=\"mc_embed_signup\">\n\n\t\t\t<form action=\"\/\/themezee.us7.list-manage.com\/subscribe\/post?u=6b585fc21558eb35c60b0a044&amp;id=c3c4e4cf53\" method=\"post\" id=\"mc-embedded-subscribe-form\" name=\"mc-embedded-subscribe-form\" class=\"validate\" target=\"_blank\" novalidate>\n\n\t\t\t\t<div id=\"mc_embed_signup_scroll\">\n\n\t\t\t\t\t<div class=\"mc-field-group\">\n\t\t\t\t\t\t<label for=\"mce-EMAIL\">Email Address<\/label>\n\t\t\t\t\t\t<input type=\"email\" value=\"\" name=\"EMAIL\" class=\"email\" id=\"mce-EMAIL\" placeholder=\"Enter your email address here\" required>\n\t\t\t\t\t<\/div>\n\n\t\t\t\t\t<div style=\"position: absolute; left: -5000px;\" aria-hidden=\"true\"><input type=\"text\" name=\"b_6b585fc21558eb35c60b0a044_c3c4e4cf53\" tabindex=\"-1\" value=\"\"><\/div>\n\t\t\t\t\t<div class=\"clear\"><input type=\"submit\" value=\"Subscribe\" name=\"subscribe\" id=\"mc-embedded-subscribe\" class=\"button\"><\/div>\n\n\t\t\t\t<\/div>\n\n\t\t\t<\/form>\n\n\t\t<\/div>\n\n\t\t<br \/>\n<small>No spam, unsubscribe at any time<\/small><\/p>\n","css":{"background_color":"#eefaff","color":"#333333","width":380,"border_color":"#1a6bb2","border_width":15,"border_style":"solid","position":"bottom-right"},"trigger":{"method":"percentage","value":40},"animation":"fade","cookie":{"triggered":24,"dismissed":1440},"rehide":true,"position":"bottom-right","minimumScreenWidth":400,"closable":true}]};
/* ]]> */
</script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/boxzilla/assets/js/script.min.js?ver=3.1.5'></script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/wp-jquery-lightbox/jquery.touchwipe.min.js?ver=1.4.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var JQLBSettings = {"showTitle":"1","showCaption":"1","showNumbers":"1","fitToScreen":"0","resizeSpeed":"400","showDownload":"0","navbarOnTop":"0","marginSize":"0","slideshowSpeed":"4000","prevLinkTitle":"previous image","nextLinkTitle":"next image","closeTitle":"close image gallery","image":"Image ","of":" of ","download":"Download","pause":"(pause slideshow)","play":"(play slideshow)"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-content/plugins/wp-jquery-lightbox/jquery.lightbox.min.js?ver=1.4.6'></script>
<script type='text/javascript' src='https://cdn.themezee.com/wp-includes/js/wp-embed.min.js'></script>

</body>

</html>